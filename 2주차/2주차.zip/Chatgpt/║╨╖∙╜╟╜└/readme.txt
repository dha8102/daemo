[실습 설명]
reviews_train.csv에는 news review training data와 label이 있습니다.
reviews_test.csv에는 news review test data가 있고, label은 비어 있습니다.
reviews_train.csv를 읽어들여 간단한 기계학습 모델로 학습시키고,
reviews_test.csv의 문장을 분류한 결과를 label 행에 출력하는 코드를 작성해 보세요.
label을 모두 달았으면, reviews_test_answer.csv의 정답 label과 비교해서 정확도를 출력하는 코드를 작성해 보세요.